// src/redux/clock/clockTypes.js
export const UPDATE_TIME = "UPDATE_TIME";

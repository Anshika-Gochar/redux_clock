// src/App.js
import React from 'react';
import Clock from './components/clock';

function App() {
  return (
    <div className="App">
      <Clock />
    </div>
  );
}

export default App;
